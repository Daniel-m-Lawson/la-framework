from typing import TypeVar, Generic

from la_framework.la_keyed_class import LaKeyedClass


T = TypeVar("T", bound=LaKeyedClass)


class LaList(Generic[T]):
    """A list of items that can be accessed by a key."""

    def __init__(self, item_type: type[T]):
        self._item_type = item_type
        self._items: list[T] = []
        self._key_map: dict = {}

    def append(self, item: T):
        if not isinstance(item, self._item_type):
            raise TypeError("Incorrect type")

        if item.key in self._key_map:
            raise ValueError("Duplicate key")

        self._items.append(item)
        self._key_map[item.key] = item

    def get(self, key):
        return self._key_map[key]
