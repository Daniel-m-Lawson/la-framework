from abc import ABC, abstractmethod


class LaKeyedClass(ABC):
    """A class that has a key property."""

    @property
    @abstractmethod
    def key(self):
        pass
